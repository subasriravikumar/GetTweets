﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
//using System.Web.Mvc;

namespace GetTweetsAPI.GetTweets.Controllers
{
    public class GetTweetInfoController : ApiController
    {
        [HttpGet]
        public async Task<ActionResult> GetCustomers()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://badapi.iqvia.io/swagger/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                HttpResponseMessage response = await client.GetAsync(customerApi);
                if (response.IsSuccessStatusCode)
                {
                    string jsondata = await response.Content.ReadAsStringAsync();
                    return Content(jsondata, "application/json");
                }
                return Json(1, JsonRequestBehavior.AllowGet);
            }
        }
    }
}
