﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Tweetsapp.Startup))]
namespace Tweetsapp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
