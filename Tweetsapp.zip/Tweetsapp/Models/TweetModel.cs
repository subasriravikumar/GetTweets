﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PagedList;

namespace Tweetsapp.Models
{
    public class TweetModel
    {
        public string Id { set; get; }

        public string stamp { set; get; }

        public string text { set; get; }

    }
}