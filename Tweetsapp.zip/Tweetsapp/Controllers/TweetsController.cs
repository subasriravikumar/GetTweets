﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Tweetsapp.Models;
using PagedList;

namespace Tweetsapp.Controllers
{
    public class TweetsController : Controller
    {
                
        string Baseurl = "https://badapi.iqvia.io/";

        public async Task<ActionResult> Index( string startdate, string enddate, int page =1)
        {
            List<TweetModel> TweetInfo = new List<TweetModel>();

            using (var client = new HttpClient())
            {
                 
                client.BaseAddress = new Uri(Baseurl);
                client.DefaultRequestHeaders.Clear();

                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage Res = await client.GetAsync("api/v1/Tweets?startDate="+startdate+"&endDate="+enddate);

                if (Res.IsSuccessStatusCode)
                {
                      
                    var TweetResponse = Res.Content.ReadAsStringAsync().Result;
                    TweetInfo = JsonConvert.DeserializeObject<List<TweetModel>>(TweetResponse);

                }
                
                return View(TweetInfo.ToPagedList(page,10));
            }
        }

       
    }
}